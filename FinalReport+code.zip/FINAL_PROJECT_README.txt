Here are the files included in our reports and what they mean
RCNN.py: implementation of our machine learning algorithm

facedetection.py: This is the code that runs the face detection and displays the emotion of the person. This is the main file in our project. 
To use our software, run the code and once you see your face on the screen, hit escape on the keyboard. the code will then display a a screenshot and an emotion above that.

Finalmodel40: this is the files for th weights of our CNN

archive: this contains our training and testing data

image_display.py: contains a helper function for facedetection.py

Final Project Report - Joseph Alverson, Eugene Antwi Boasiako, Noah Bohannon.PDF:
provides the report we wrote about the project